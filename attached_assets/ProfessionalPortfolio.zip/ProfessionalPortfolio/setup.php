<?php
/**
 * Database Setup Script for Render.com
 * 
 * This script initializes the PostgreSQL database on Render.com
 * It converts the MySQL schema to PostgreSQL and creates the necessary tables
 * 
 * Only run this script once during initial setup!
 */

// Include database configuration
require_once 'php/config.php';

// Check if environment is Render.com (PostgreSQL)
if (!isset($isPDO) || !$isPDO) {
    die('This setup script is intended for Render.com PostgreSQL database only.');
}

// Define PostgreSQL schema
$pgsqlSchema = [
    // Users table
    "CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );",

    // Blog posts table
    "CREATE TABLE IF NOT EXISTS blog_posts (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        category VARCHAR(50) DEFAULT 'general',
        image_url VARCHAR(255) DEFAULT NULL,
        video_url VARCHAR(255) DEFAULT NULL,
        featured BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );",

    // Projects table
    "CREATE TABLE IF NOT EXISTS projects (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        category VARCHAR(50) DEFAULT 'other',
        image_url VARCHAR(255) DEFAULT NULL,
        link VARCHAR(255) DEFAULT NULL,
        tags VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );",

    // Research papers table
    "CREATE TABLE IF NOT EXISTS research_papers (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        conference VARCHAR(255) NOT NULL,
        date DATE DEFAULT NULL,
        link VARCHAR(255) DEFAULT NULL,
        abstract TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );",

    // Contact messages table
    "CREATE TABLE IF NOT EXISTS contact_messages (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );"
];

// Sample project data
$projectData = [
    "INSERT INTO projects (title, description, category, link, tags) VALUES
    ('Smart Waiter Call System', 'An innovative system designed to modernize restaurant service by providing a digital solution for customers to call waiters. Enhances customer experience and improves restaurant efficiency.', 'ai', 'https://github.com/SanjidHossain/Smart-Waiter-Call-System', 'IoT, Hardware, Customer Service, Restaurant Tech'),
    ('MEME Finder AI', 'An AI-powered tool that searches and retrieves memes based on text descriptions. Uses natural language processing to understand meme content and context for accurate retrieval.', 'ai', 'https://github.com/SanjidHossain/MEME-Finder-AI', 'AI, NLP, Image Recognition, Python, Deep Learning'),
    ('Traffic Management System (YOLO approach)', 'An advanced traffic management solution that uses YOLO (You Only Look Once) object detection to monitor and analyze traffic patterns in real-time. Helps optimize traffic flow and enhance road safety.', 'ai', 'https://github.com/SanjidHossain/Traffic-Managment-System-YOLO-approach', 'Computer Vision, YOLO, Object Detection, Traffic Analysis'),
    ('AI Schema Extractor', 'A tool that automatically extracts database schemas from existing applications using AI. Simplifies database migration and documentation processes for developers.', 'ai', 'https://github.com/SanjidHossain/AI-schema-extractor', 'AI, Database, Schema Extraction, Development Tools'),
    ('FoodLens AI', 'A complete web application built with flask that can recognize and classify foods, their Origins and The Restrictive Ingredients. The application can use both Image and Text from user and generate the result using multiple layers of AI models.', 'ai', 'https://github.com/SanjidHossain', 'Python, Flask, AI, Computer Vision, NLP'),
    ('MultiLabel Article Classifier', 'A web application that can classify any form of News or article (complete or partial) from text (English) using ML model consisting of 18 categories.', 'ai', 'https://github.com/SanjidHossain', 'Python, NLP, Machine Learning, Classification'),
    ('Data Analysis on Quality of Life', 'A complete data analysis project that uses population, GDP, Life expectancy and inflation rate data to determine the quality of life around the world & more detailed analys on multiple continents.', 'data', 'https://github.com/SanjidHossain', 'Data Analysis, Python, Pandas, Visualization');"
];

// Sample research papers data
$researchData = [
    "INSERT INTO research_papers (title, conference, date, link, abstract) VALUES
    ('Refining Bengali Hate Speech Detection: Multi-Label Classification Using RNN and LSTM', 'ICACTCE''24 (Springer Lecture Notes in Networks and Systems LNNS)', NULL, '#', 'This research paper explores advanced methods for detecting hate speech in Bengali language using Recurrent Neural Networks (RNN) and Long Short-Term Memory (LSTM) models. The study implements a multi-label classification approach to categorize various forms of hate speech with improved accuracy.'),
    ('Road Condition Detection and Crowdsourced Data Collection for Accident Prevention: A Deep Learning Approach', 'International Conference on Image Processing Theory, Tools and Applications (IPTA), France', '2023-10-15', '#', 'This paper presents a deep learning approach for detecting road conditions through image processing and leveraging crowdsourced data collection to prevent accidents. The system uses convolutional neural networks to classify road conditions from images captured by users.'),
    ('Hate Speech Detection Using Machine Learning In Bengali Languages', 'International Conference on Intelligent Computing and Control Systems (ICICCS)', '2022-05-20', '#', 'This research focuses on developing machine learning models for detecting hate speech in Bengali language. Various classification algorithms are compared to determine the most effective approach for this challenging natural language processing task.');"
];

// Create default admin user
$adminUser = [
    "INSERT INTO users (username, password, email) VALUES
    ('admin', '$2y$10$YourPasswordHashHere', 'sanjidds99@gmail.com');"
];

// Execute schema creation
try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Create tables
    foreach ($pgsqlSchema as $query) {
        $conn->exec($query);
    }
    
    // Insert sample projects
    foreach ($projectData as $query) {
        $conn->exec($query);
    }
    
    // Insert sample research papers
    foreach ($researchData as $query) {
        $conn->exec($query);
    }
    
    // Create admin user (commented out for security reasons - uncomment and set a proper password hash when needed)
    // foreach ($adminUser as $query) {
    //     $conn->exec($query);
    // }
    
    // Commit transaction
    $conn->commit();
    
    echo "<h1>Database Setup Successful!</h1>";
    echo "<p>All database tables have been created and sample data has been inserted.</p>";
    echo "<p><strong>Important:</strong> For security reasons, please delete this file after using it!</p>";
    echo "<p><a href='/'>Go to Homepage</a></p>";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    $conn->rollBack();
    echo "<h1>Database Setup Failed</h1>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}