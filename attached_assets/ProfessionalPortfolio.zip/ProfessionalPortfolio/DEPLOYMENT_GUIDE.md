# Deployment Guide for Md. Sanjid Hossain's Portfolio Website

This guide provides step-by-step instructions for deploying your portfolio website to Render.com, a cloud platform that offers free hosting for static sites and web services.

## Requirements
- PHP >= 7.4
- MySQL >= 5.7
- Git repository (GitHub, GitLab, or Bitbucket)

## Local Environment Setup
Before deploying, make sure your local environment is properly configured:
1. Ensure PHP and MySQL are installed on your development environment
2. Import the database structure from `sql/database.sql` to your local MySQL server
3. Configure database connection in `php/config.php` with your local credentials
4. Test your website locally using `php -S 0.0.0.0:5000` to verify everything works

## Project File Structure
The portfolio website follows this structure:
```
├── admin/                 # Admin panel interface
├── assets/                # Images, icons, and other static assets
├── attached_assets/       # User-uploaded images and documents
├── css/                   # CSS stylesheets
│   ├── style.css          # Main stylesheet
│   └── responsive.css     # Responsive design rules
├── js/                    # JavaScript files
│   ├── main.js            # Main functionality
│   ├── theme.js           # Theme toggle functionality
│   └── admin.js           # Admin panel functionality
├── php/                   # Backend PHP scripts
│   ├── config.php         # Database configuration
│   ├── contact.php        # Contact form handler
│   ├── blog.php           # Blog functionality
│   └── projects.php       # Projects functionality
├── sql/                   # SQL database scripts
│   └── database.sql       # Database structure and sample data
├── index.html             # Homepage
├── blog.html              # Blog listing page
├── blog-post.html         # Individual blog post template
└── projects.html          # Projects listing page
```

## Detailed Deployment Guide for Render.com

### 1. Prepare Your Repository
1. Make sure all your code is committed to your Git repository
2. Create a `composer.json` file in the root of your project with the following content:
   ```json
   {
       "name": "sanjid/portfolio",
       "description": "Md. Sanjid Hossain's Portfolio Website",
       "require": {
           "php": ">=7.4",
           "ext-mysqli": "*"
       }
   }
   ```
3. Create a file named `render.yaml` in the root of your project with the following content:
   ```yaml
   services:
     - type: web
       name: sanjid-portfolio
       env: php
       buildCommand: composer install
       startCommand: php -S 0.0.0.0:$PORT -t .
       envVars:
         - key: DB_HOST
           sync: false
         - key: DB_NAME
           sync: false
         - key: DB_USER
           sync: false
         - key: DB_PASS
           sync: false
   databases:
     - name: portfolio-db
       plan: free
       databaseName: portfolio
   ```

### 2. Sign Up for Render.com
1. Go to [Render.com](https://render.com/)
2. Sign up for a new account or log in to your existing account
3. Verify your email if required

### 3. Create a New MySQL Database
1. In your Render dashboard, click on the "New +" button in the top right
2. Select "PostgreSQL" (Render doesn't offer MySQL, but you can adapt your code)
3. Fill in the database details:
   - **Name**: `portfolio-db`
   - **Database**: `portfolio`
   - **User**: Leave as default
   - **Region**: Choose the region closest to your target audience
   - **PostgreSQL Version**: Choose the latest available version
4. Select the "Free" plan
5. Click "Create Database"
6. Once created, note down the following information from the database page:
   - **Internal Database URL** (for connecting from Render services)
   - **External Database URL** (for connecting from external services)
   - **Username**
   - **Password**

### 4. Modify Your Code for PostgreSQL
Since Render offers PostgreSQL instead of MySQL, you'll need to modify your PHP database connection code:

1. Edit your `php/config.php` file to support both MySQL and PostgreSQL:
   ```php
   <?php
   // Check if environment variables are set (Render.com)
   if (getenv('DATABASE_URL')) {
       // Parse the PostgreSQL connection string
       $db_url = parse_url(getenv('DATABASE_URL'));
       $host = $db_url['host'];
       $username = $db_url['user'];
       $password = $db_url['pass'];
       $database = ltrim($db_url['path'], '/');
       $port = $db_url['port'];
       
       // Use PDO for PostgreSQL connection
       try {
           $conn = new PDO("pgsql:host=$host;port=$port;dbname=$database;user=$username;password=$password");
           $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
           $isPDO = true;
       } catch (PDOException $e) {
           die("Connection failed: " . $e->getMessage());
       }
   } else {
       // Local MySQL connection
       $host = 'localhost';
       $username = 'root';
       $password = '';
       $database = 'portfolio';
       
       // Create mysqli connection for local development
       $conn = new mysqli($host, $username, $password, $database);
       $isPDO = false;
       
       // Check connection
       if ($conn->connect_error) {
           die("Connection failed: " . $conn->connect_error);
       }
   }
   
   // Helper function for sanitizing input
   function sanitizeInput($data) {
       global $conn, $isPDO;
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       
       if ($isPDO) {
           return $data; // PDO uses prepared statements
       } else {
           return $conn->real_escape_string($data);
       }
   }
   
   // Helper function for JSON responses
   function jsonResponse($success, $message, $data = []) {
       header('Content-Type: application/json');
       echo json_encode([
           'success' => $success,
           'message' => $message,
           'data' => $data
       ]);
       exit;
   }
   ?>
   ```

2. You'll also need to convert your MySQL queries to PostgreSQL format:
   - Replace backticks (\`) with double quotes for table/column names
   - Replace `AUTO_INCREMENT` with `SERIAL`
   - Update any MySQL-specific functions to PostgreSQL equivalents

### 5. Create a New Web Service
1. In your Render dashboard, click on the "New +" button
2. Select "Web Service"
3. Connect your Git repository (GitHub, GitLab, or Bitbucket)
4. Select the repository containing your portfolio website
5. Configure your web service:
   - **Name**: `sanjid-portfolio`
   - **Environment**: `PHP`
   - **Region**: Choose the same region as your database
   - **Branch**: Select your main branch (usually `main` or `master`)
   - **Build Command**: `composer install`
   - **Start Command**: `php -S 0.0.0.0:$PORT -t .`
   - **Plan**: Free

### 6. Configure Environment Variables
1. Scroll down to the "Environment" section
2. Add the following environment variables:
   - `DATABASE_URL`: Use the **Internal Database URL** from your database settings
   - `PHP_VERSION`: `7.4` (or your preferred version)
   - You can also add other environment variables as needed for your application

### 7. Deploy Your Web Service
1. Click "Create Web Service"
2. Render will begin deploying your application
3. You can monitor the deployment progress in the "Events" tab
4. Once deployment is complete, your website will be available at the provided URL (usually `https://your-service-name.onrender.com`)

### 8. Setup Database Tables
You have two options for setting up your database tables:

1. **Manual Import** (recommended for first deployment):
   - Convert your `database.sql` file to PostgreSQL syntax
   - Log in to your database using a PostgreSQL client (like pgAdmin or DBeaver)
   - Run the converted SQL to create your tables and insert data

2. **Add Database Migration to Your Code**:
   - Create a `setup.php` file in your project root
   - Add code to read your SQL file and execute it when accessed
   - Visit `https://your-service-name.onrender.com/setup.php` to run the setup

### 9. Custom Domain (Optional)
1. In your web service settings, click on "Custom Domain"
2. Enter your domain name (e.g., `sanjid.com` or `portfolio.sanjid.com`)
3. Follow the instructions to update your DNS settings:
   - Add a CNAME record pointing to your Render URL
   - Or use Render's nameservers for complete DNS management
4. Wait for DNS propagation (can take up to 48 hours)
5. Render will automatically provide SSL certificates

### 10. Maintenance and Updates
- To update your website, simply push changes to your Git repository
- Render will automatically detect changes and redeploy your service
- You can monitor deployments in the "Events" tab
- For database changes, you'll need to manually update the database schema

## Troubleshooting

### Common Issues:
1. **Database Connection Errors**:
   - Verify your environment variables are set correctly
   - Check that your code correctly parses the database URL
   - Try connecting to the database using an external tool to verify credentials

2. **Missing PHP Extensions**:
   - If you need additional PHP extensions, specify them in your `composer.json` file
   - Example: `"ext-gd": "*"` for image processing

3. **File Permissions**:
   - Ensure uploaded files have proper permissions
   - Use a persistent disk or cloud storage for user uploads

4. **Service Not Starting**:
   - Check the logs in the "Logs" tab for errors
   - Verify your start command is correct
   - Make sure your PHP version is compatible with your code

## Resources
- [Render PHP Documentation](https://render.com/docs/deploy-php)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [PHP PDO Documentation](https://www.php.net/manual/en/book.pdo.php)

---

For additional support, contact Md. Sanjid Hossain at sanjidds99@gmail.com