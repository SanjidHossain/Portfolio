<?php
/**
 * Research Papers Management API
 * 
 * Handles research paper CRUD operations
 */

// Include database configuration
require_once 'config.php';

// Set headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Connect to database
$conn = dbConnect();

if (!$conn) {
    jsonResponse(false, 'Database connection error. Please try again later.');
}

// Determine action based on request method and parameters
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch ($action) {
    case 'getAll':
        getAllPapers();
        break;
    
    case 'get':
        getPaper();
        break;
    
    case 'create':
        createPaper();
        break;
    
    case 'update':
        updatePaper();
        break;
    
    case 'delete':
        deletePaper();
        break;
    
    default:
        jsonResponse(false, 'Invalid action.');
}

// Get all research papers
function getAllPapers() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM research_papers ORDER BY date DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $papers = [];
    
    while ($row = $result->fetch_assoc()) {
        $papers[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Research papers retrieved successfully.', ['papers' => $papers]);
}

// Get a specific research paper
function getPaper() {
    global $conn;
    
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid research paper ID.');
    }
    
    $stmt = $conn->prepare("SELECT * FROM research_papers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Research paper not found.');
    }
    
    $paper = $result->fetch_assoc();
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Research paper retrieved successfully.', ['paper' => $paper]);
}

// Create a new research paper
function createPaper() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $conference = isset($_POST['conference']) ? sanitizeInput($_POST['conference']) : '';
    $date = isset($_POST['date']) && !empty($_POST['date']) ? $_POST['date'] : null;
    $link = isset($_POST['link']) ? sanitizeInput($_POST['link']) : '';
    $abstract = isset($_POST['abstract']) ? sanitizeInput($_POST['abstract']) : '';
    
    // Validate input
    if (empty($title) || empty($conference)) {
        jsonResponse(false, 'Title and conference are required.');
    }
    
    // Insert new paper
    $stmt = $conn->prepare("INSERT INTO research_papers (title, conference, date, link, abstract) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $conference, $date, $link, $abstract);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error creating research paper: ' . $stmt->error);
    }
    
    $newPaperId = $stmt->insert_id;
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Research paper created successfully.', ['id' => $newPaperId]);
}

// Update an existing research paper
function updatePaper() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $conference = isset($_POST['conference']) ? sanitizeInput($_POST['conference']) : '';
    $date = isset($_POST['date']) && !empty($_POST['date']) ? $_POST['date'] : null;
    $link = isset($_POST['link']) ? sanitizeInput($_POST['link']) : '';
    $abstract = isset($_POST['abstract']) ? sanitizeInput($_POST['abstract']) : '';
    
    // Validate input
    if ($id <= 0 || empty($title) || empty($conference)) {
        jsonResponse(false, 'Invalid input. ID, title, and conference are required.');
    }
    
    // Update paper
    $stmt = $conn->prepare("UPDATE research_papers SET title = ?, conference = ?, date = ?, link = ?, abstract = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $title, $conference, $date, $link, $abstract, $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error updating research paper: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'No changes made or research paper not found.');
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Research paper updated successfully.');
}

// Delete a research paper
function deletePaper() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid research paper ID.');
    }
    
    $stmt = $conn->prepare("DELETE FROM research_papers WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error deleting research paper: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Research paper not found.');
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Research paper deleted successfully.');
}
?>
