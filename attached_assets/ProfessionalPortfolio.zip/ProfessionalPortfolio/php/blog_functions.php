<?php
/**
 * Blog Management Functions
 * 
 * Handles CRUD operations for blog posts
 * 
 * @author Md. Sanjid Hossain
 * @version 1.0
 */

// Include database connection
require_once 'db_connect.php';

// Set headers to handle AJAX requests
header('Content-Type: application/json');

// Check if the user is logged in for write operations
function checkLogin() {
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Authentication required.'
        ]);
        exit;
    }
}

// Get all blogs
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getAll') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT * FROM blogs ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    if ($result) {
        $blogs = [];
        
        while ($row = $result->fetch_assoc()) {
            $blogs[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'blogs' => $blogs
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch blogs: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get blog count
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'count') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT COUNT(*) as count FROM blogs";
    $result = $conn->query($sql);
    
    if ($result) {
        $row = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'count' => $row['count']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch blog count: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get a single blog post
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get' && isset($_GET['id'])) {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    
    $sql = "SELECT * FROM blogs WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $blog = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'blog' => $blog
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Blog post not found.'
        ]);
    }
    
    $stmt->close();
    closeDB();
    exit;
}

// Blog operations (create, update, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check login status for write operations
    checkLogin();
    
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    // Create or update blog post
    if (isset($_POST['action']) && ($_POST['action'] === 'create' || $_POST['action'] === 'update')) {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $content = filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING);
        $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
        $image_url = filter_input(INPUT_POST, 'image_url', FILTER_SANITIZE_URL);
        
        // Validate required fields
        if (empty($title) || empty($content) || empty($category)) {
            echo json_encode([
                'success' => false,
                'message' => 'Please fill in all required fields.'
            ]);
            exit;
        }
        
        if (isset($_POST['blog_id']) && !empty($_POST['blog_id'])) {
            // Update existing blog post
            $blog_id = filter_input(INPUT_POST, 'blog_id', FILTER_SANITIZE_NUMBER_INT);
            
            $sql = "UPDATE blogs SET title = ?, content = ?, category = ?, image_url = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $title, $content, $category, $image_url, $blog_id);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Blog post updated successfully.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update blog post: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        } else {
            // Create new blog post
            $sql = "INSERT INTO blogs (title, content, category, image_url) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $title, $content, $category, $image_url);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Blog post created successfully.',
                    'blog_id' => $stmt->insert_id
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to create blog post: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        }
    }
    
    // Delete blog post
    if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['blog_id'])) {
        $blog_id = filter_input(INPUT_POST, 'blog_id', FILTER_SANITIZE_NUMBER_INT);
        
        $sql = "DELETE FROM blogs WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $blog_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Blog post deleted successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to delete blog post: ' . $stmt->error
            ]);
        }
        
        $stmt->close();
    }
    
    closeDB();
    exit;
}

// Default response for invalid requests
echo json_encode([
    'success' => false,
    'message' => 'Invalid request.'
]);
?>
