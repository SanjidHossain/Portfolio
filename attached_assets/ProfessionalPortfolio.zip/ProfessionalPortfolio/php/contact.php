<?php
/**
 * Contact Form Handler
 * 
 * Processes contact form submissions and sends email notifications
 */

// Include database configuration
require_once 'config.php';

// Set headers to prevent caching
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = isset($_POST['name']) ? sanitizeInput($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitizeInput($_POST['email']) : '';
    $subject = isset($_POST['subject']) ? sanitizeInput($_POST['subject']) : '';
    $message = isset($_POST['message']) ? sanitizeInput($_POST['message']) : '';
    
    // Validate input
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        jsonResponse(false, 'Please fill in all fields.');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Please enter a valid email address.');
    }
    
    // Connect to database
    $conn = dbConnect();
    
    if (!$conn) {
        jsonResponse(false, 'Database connection error. Please try again later.');
    }
    
    // Store message in database
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error saving your message. Please try again later.');
    }
    
    $stmt->close();
    $conn->close();
    
    // Send email notification
    $recipientEmail = 'sanjidds99@gmail.com';
    $emailSubject = "New Contact Form Message: $subject";
    
    $emailBody = "
    <html>
    <head>
        <title>New Contact Form Message</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
            h1 { color: #4285F4; }
            .info { margin-bottom: 20px; }
            .info p { margin: 5px 0; }
            .message { background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h1>New Contact Form Message</h1>
            <div class='info'>
                <p><strong>Name:</strong> $name</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Subject:</strong> $subject</p>
            </div>
            <div class='message'>
                <p><strong>Message:</strong></p>
                <p>" . nl2br($message) . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Set headers for HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: $name <$email>" . "\r\n";
    
    // Send email
    $mailSent = mail($recipientEmail, $emailSubject, $emailBody, $headers);
    
    if ($mailSent) {
        jsonResponse(true, 'Thank you! Your message has been sent successfully.');
    } else {
        // Message is saved in the database even if email fails
        jsonResponse(true, 'Your message has been received, but there was an issue sending the email notification.');
    }
} else {
    // Handle non-POST requests
    jsonResponse(false, 'Invalid request method.');
}
?>
