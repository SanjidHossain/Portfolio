<?php
/**
 * Database Connection
 * 
 * Establishes a connection to the MySQL database
 * 
 * @author Md. Sanjid Hossain
 * @version 1.0
 */

// Database configuration
$db_host = "localhost";
$db_name = "portfolio";
$db_user = "root";
$db_pass = "";

// Create connection
$conn = null;

/**
 * Function to connect to the database
 * 
 * @return mysqli|null The database connection object or null on error
 */
function connectDB() {
    global $conn, $db_host, $db_name, $db_user, $db_pass;
    
    if ($conn === null) {
        // Create connection
        $conn = new mysqli($db_host, $db_user, $db_pass);
        
        // Check connection
        if ($conn->connect_error) {
            error_log("Connection failed: " . $conn->connect_error);
            return null;
        }
        
        // Check if database exists, if not create it
        $result = $conn->query("SHOW DATABASES LIKE '$db_name'");
        if ($result->num_rows == 0) {
            // Create database
            $sql = "CREATE DATABASE $db_name";
            if ($conn->query($sql) === TRUE) {
                error_log("Database created successfully");
            } else {
                error_log("Error creating database: " . $conn->error);
                return null;
            }
        }
        
        // Select database
        $conn->select_db($db_name);
        
        // Check if tables exist, if not create them
        createTables($conn);
    }
    
    return $conn;
}

/**
 * Function to create necessary tables if they don't exist
 * 
 * @param mysqli $conn Database connection
 */
function createTables($conn) {
    // Create Admin Users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating users table: " . $conn->error);
    }
    
    // Create Blogs table
    $sql = "CREATE TABLE IF NOT EXISTS blogs (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        category VARCHAR(50) NOT NULL,
        image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating blogs table: " . $conn->error);
    }
    
    // Create Projects table
    $sql = "CREATE TABLE IF NOT EXISTS projects (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        category VARCHAR(50) NOT NULL,
        image_url VARCHAR(255),
        github_url VARCHAR(255),
        live_url VARCHAR(255),
        tags VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating projects table: " . $conn->error);
    }
    
    // Create Research Papers table
    $sql = "CREATE TABLE IF NOT EXISTS research (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        publication VARCHAR(255) NOT NULL,
        year INT(4) NOT NULL,
        description TEXT NOT NULL,
        image_url VARCHAR(255),
        paper_url VARCHAR(255),
        tags VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql) !== TRUE) {
        error_log("Error creating research table: " . $conn->error);
    }
    
    // Check if default admin user exists
    $result = $conn->query("SELECT * FROM users WHERE username = 'admin'");
    if ($result->num_rows == 0) {
        // Create default admin user
        $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password) VALUES ('admin', '$password_hash')";
        
        if ($conn->query($sql) === TRUE) {
            error_log("Default admin user created successfully");
        } else {
            error_log("Error creating default admin user: " . $conn->error);
        }
    }
}

/**
 * Function to close the database connection
 */
function closeDB() {
    global $conn;
    
    if ($conn !== null) {
        $conn->close();
        $conn = null;
    }
}
?>
