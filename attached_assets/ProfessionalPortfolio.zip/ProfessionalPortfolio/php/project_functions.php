<?php
/**
 * Project and Research Management Functions
 * 
 * Handles CRUD operations for projects and research papers
 * 
 * @author Md. Sanjid Hossain
 * @version 1.0
 */

// Include database connection
require_once 'db_connect.php';

// Set headers to handle AJAX requests
header('Content-Type: application/json');

// Check if the user is logged in for write operations
function checkLogin() {
    session_start();
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Authentication required.'
        ]);
        exit;
    }
}

// Get all projects
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getAll') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT * FROM projects ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    if ($result) {
        $projects = [];
        
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'projects' => $projects
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch projects: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get project count
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'count') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT COUNT(*) as count FROM projects";
    $result = $conn->query($sql);
    
    if ($result) {
        $row = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'count' => $row['count']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch project count: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get research count
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'count_research') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT COUNT(*) as count FROM research";
    $result = $conn->query($sql);
    
    if ($result) {
        $row = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'count' => $row['count']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch research count: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get a single project
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get' && isset($_GET['id'])) {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    
    $sql = "SELECT * FROM projects WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $project = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'project' => $project
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Project not found.'
        ]);
    }
    
    $stmt->close();
    closeDB();
    exit;
}

// Get all research papers
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_research') {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $sql = "SELECT * FROM research ORDER BY year DESC, created_at DESC";
    $result = $conn->query($sql);
    
    if ($result) {
        $research = [];
        
        while ($row = $result->fetch_assoc()) {
            $research[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'research' => $research
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch research papers: ' . $conn->error
        ]);
    }
    
    closeDB();
    exit;
}

// Get a single research paper
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_research_item' && isset($_GET['id'])) {
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    
    $sql = "SELECT * FROM research WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $research = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'research' => $research
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Research paper not found.'
        ]);
    }
    
    $stmt->close();
    closeDB();
    exit;
}

// Project operations (create, update, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check login status for write operations
    checkLogin();
    
    $conn = connectDB();
    
    if (!$conn) {
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed.'
        ]);
        exit;
    }
    
    // Create or update project
    if (isset($_POST['action']) && ($_POST['action'] === 'create' || $_POST['action'] === 'update')) {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
        $image_url = filter_input(INPUT_POST, 'image_url', FILTER_SANITIZE_URL);
        $github_url = filter_input(INPUT_POST, 'github_url', FILTER_SANITIZE_URL);
        $live_url = filter_input(INPUT_POST, 'live_url', FILTER_SANITIZE_URL);
        $tags = filter_input(INPUT_POST, 'tags', FILTER_SANITIZE_STRING);
        
        // Validate required fields
        if (empty($title) || empty($description) || empty($category)) {
            echo json_encode([
                'success' => false,
                'message' => 'Please fill in all required fields.'
            ]);
            exit;
        }
        
        if (isset($_POST['project_id']) && !empty($_POST['project_id'])) {
            // Update existing project
            $project_id = filter_input(INPUT_POST, 'project_id', FILTER_SANITIZE_NUMBER_INT);
            
            $sql = "UPDATE projects SET title = ?, description = ?, category = ?, image_url = ?, github_url = ?, live_url = ?, tags = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssi", $title, $description, $category, $image_url, $github_url, $live_url, $tags, $project_id);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Project updated successfully.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update project: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        } else {
            // Create new project
            $sql = "INSERT INTO projects (title, description, category, image_url, github_url, live_url, tags) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $title, $description, $category, $image_url, $github_url, $live_url, $tags);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Project created successfully.',
                    'project_id' => $stmt->insert_id
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to create project: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        }
    }
    
    // Delete project
    if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['project_id'])) {
        $project_id = filter_input(INPUT_POST, 'project_id', FILTER_SANITIZE_NUMBER_INT);
        
        $sql = "DELETE FROM projects WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $project_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Project deleted successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to delete project: ' . $stmt->error
            ]);
        }
        
        $stmt->close();
    }
    
    // Create or update research paper
    if (isset($_POST['action']) && ($_POST['action'] === 'create_research' || $_POST['action'] === 'update_research')) {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $publication = filter_input(INPUT_POST, 'publication', FILTER_SANITIZE_STRING);
        $year = filter_input(INPUT_POST, 'year', FILTER_SANITIZE_NUMBER_INT);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $image_url = filter_input(INPUT_POST, 'image_url', FILTER_SANITIZE_URL);
        $paper_url = filter_input(INPUT_POST, 'paper_url', FILTER_SANITIZE_URL);
        $tags = filter_input(INPUT_POST, 'tags', FILTER_SANITIZE_STRING);
        
        // Validate required fields
        if (empty($title) || empty($publication) || empty($year) || empty($description)) {
            echo json_encode([
                'success' => false,
                'message' => 'Please fill in all required fields.'
            ]);
            exit;
        }
        
        if (isset($_POST['research_id']) && !empty($_POST['research_id'])) {
            // Update existing research paper
            $research_id = filter_input(INPUT_POST, 'research_id', FILTER_SANITIZE_NUMBER_INT);
            
            $sql = "UPDATE research SET title = ?, publication = ?, year = ?, description = ?, image_url = ?, paper_url = ?, tags = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssissssi", $title, $publication, $year, $description, $image_url, $paper_url, $tags, $research_id);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Research paper updated successfully.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update research paper: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        } else {
            // Create new research paper
            $sql = "INSERT INTO research (title, publication, year, description, image_url, paper_url, tags) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssissss", $title, $publication, $year, $description, $image_url, $paper_url, $tags);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Research paper added successfully.',
                    'research_id' => $stmt->insert_id
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to add research paper: ' . $stmt->error
                ]);
            }
            
            $stmt->close();
        }
    }
    
    // Delete research paper
    if (isset($_POST['action']) && $_POST['action'] === 'delete_research' && isset($_POST['research_id'])) {
        $research_id = filter_input(INPUT_POST, 'research_id', FILTER_SANITIZE_NUMBER_INT);
        
        $sql = "DELETE FROM research WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $research_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Research paper deleted successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to delete research paper: ' . $stmt->error
            ]);
        }
        
        $stmt->close();
    }
    
    closeDB();
    exit;
}

// Default response for invalid requests
echo json_encode([
    'success' => false,
    'message' => 'Invalid request.'
]);
?>
