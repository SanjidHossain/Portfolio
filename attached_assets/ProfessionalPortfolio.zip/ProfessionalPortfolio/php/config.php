<?php
/**
 * Database Configuration
 * 
 * This file contains database connection settings and helper functions
 */

// Define database connection constants
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sanjid_portfolio');

// Error reporting
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Connect to database
function dbConnect() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        // Set character set
        $conn->set_charset("utf8mb4");
        
        return $conn;
    } catch (Exception $e) {
        // Log error
        error_log("Database connection error: " . $e->getMessage());
        
        // Return false to indicate connection error
        return false;
    }
}

// Secure input data
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// JSON response helper
function jsonResponse($success, $message, $data = null) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response = array_merge($response, $data);
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Check if table exists
function tableExists($conn, $tableName) {
    $result = $conn->query("SHOW TABLES LIKE '$tableName'");
    return $result->num_rows > 0;
}

// Create needed tables if they don't exist
function setupDatabase() {
    $conn = dbConnect();
    
    if (!$conn) {
        return false;
    }
    
    // Create admin users table if it doesn't exist
    if (!tableExists($conn, 'admin_users')) {
        $sql = "CREATE TABLE admin_users (
            id INT(11) NOT NULL AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY (username),
            UNIQUE KEY (email)
        )";
        
        if (!$conn->query($sql)) {
            error_log("Error creating admin_users table: " . $conn->error);
            $conn->close();
            return false;
        }
        
        // Insert default admin user
        $defaultUsername = 'sanjid';
        $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $defaultEmail = 'sanjidds99@gmail.com';
        
        $sql = "INSERT INTO admin_users (username, password, email) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $defaultUsername, $defaultPassword, $defaultEmail);
        
        if (!$stmt->execute()) {
            error_log("Error creating default admin user: " . $stmt->error);
            $stmt->close();
            $conn->close();
            return false;
        }
        
        $stmt->close();
    }
    
    // Create blog posts table if it doesn't exist
    if (!tableExists($conn, 'blog_posts')) {
        $sql = "CREATE TABLE blog_posts (
            id INT(11) NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL,
            category VARCHAR(100) DEFAULT NULL,
            image_url VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        )";
        
        if (!$conn->query($sql)) {
            error_log("Error creating blog_posts table: " . $conn->error);
            $conn->close();
            return false;
        }
    }
    
    // Create projects table if it doesn't exist
    if (!tableExists($conn, 'projects')) {
        $sql = "CREATE TABLE projects (
            id INT(11) NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            category VARCHAR(50) NOT NULL,
            link VARCHAR(255) DEFAULT NULL,
            tags VARCHAR(255) DEFAULT NULL,
            image_url VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        )";
        
        if (!$conn->query($sql)) {
            error_log("Error creating projects table: " . $conn->error);
            $conn->close();
            return false;
        }
    }
    
    // Create research papers table if it doesn't exist
    if (!tableExists($conn, 'research_papers')) {
        $sql = "CREATE TABLE research_papers (
            id INT(11) NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            conference VARCHAR(255) NOT NULL,
            date DATE DEFAULT NULL,
            link VARCHAR(255) DEFAULT NULL,
            abstract TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        )";
        
        if (!$conn->query($sql)) {
            error_log("Error creating research_papers table: " . $conn->error);
            $conn->close();
            return false;
        }
    }
    
    // Create contact messages table if it doesn't exist
    if (!tableExists($conn, 'contact_messages')) {
        $sql = "CREATE TABLE contact_messages (
            id INT(11) NOT NULL AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            subject VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        )";
        
        if (!$conn->query($sql)) {
            error_log("Error creating contact_messages table: " . $conn->error);
            $conn->close();
            return false;
        }
    }
    
    $conn->close();
    return true;
}

// Insert sample data for development
function insertSampleData() {
    $conn = dbConnect();
    
    if (!$conn) {
        return false;
    }
    
    // Check if blog posts table is empty
    $result = $conn->query("SELECT COUNT(*) as count FROM blog_posts");
    $row = $result->fetch_assoc();
    
    if ($row['count'] == 0) {
        // Insert sample blog posts
        $blogPosts = [
            [
                'title' => 'Getting Started with Machine Learning',
                'content' => '<p>Machine learning is a powerful tool that allows computers to learn from data and make predictions or decisions without being explicitly programmed. This blog post will guide you through the basics of machine learning and how to get started with your first projects.</p><h2>What is Machine Learning?</h2><p>Machine learning is a subset of artificial intelligence that focuses on building systems that can learn from and make decisions based on data. These systems improve their performance over time as they are exposed to more data.</p><h2>Key Machine Learning Concepts</h2><ul><li><strong>Supervised Learning:</strong> The algorithm learns from labeled training data, helping it to predict outcomes for unforeseen data.</li><li><strong>Unsupervised Learning:</strong> The algorithm learns patterns from unlabeled data.</li><li><strong>Reinforcement Learning:</strong> The algorithm learns to perform an action based on reward feedback.</li></ul><h2>Getting Started</h2><p>To get started with machine learning, you need to have a good understanding of programming (preferably Python), statistics, and linear algebra. Here are some steps to begin your journey:</p><ol><li>Learn Python programming</li><li>Study statistics and probability</li><li>Understand linear algebra concepts</li><li>Start with simple datasets like Iris or MNIST</li><li>Implement basic algorithms such as linear regression or k-means clustering</li></ol><p>With these foundations, you\'ll be well on your way to becoming proficient in machine learning!</p>',
                'category' => 'AI & ML'
            ],
            [
                'title' => 'Data Visualization Techniques for Effective Communication',
                'content' => '<p>Data visualization is a critical skill for data scientists and analysts. Effective visualizations can communicate complex findings clearly and persuasively. This post explores key techniques for creating impactful data visualizations.</p><h2>Why Visualization Matters</h2><p>Humans are visual creatures. We process visual information faster and more effectively than text. Good visualizations can reveal patterns, trends, and outliers that might be missed in raw data.</p><h2>Essential Visualization Types</h2><ul><li><strong>Bar Charts:</strong> Best for comparing values across categories</li><li><strong>Line Charts:</strong> Ideal for showing trends over time</li><li><strong>Scatter Plots:</strong> Perfect for showing relationships between two variables</li><li><strong>Heatmaps:</strong> Great for displaying patterns in dense data</li><li><strong>Pie Charts:</strong> Useful for showing proportions of a whole (use sparingly)</li></ul><h2>Design Principles</h2><p>Follow these principles to create effective visualizations:</p><ol><li><strong>Simplicity:</strong> Remove clutter and unnecessary elements</li><li><strong>Clarity:</strong> Ensure your message is clear and straightforward</li><li><strong>Accuracy:</strong> Represent data truthfully without distortion</li><li><strong>Context:</strong> Provide adequate context for interpretation</li><li><strong>Accessibility:</strong> Use color schemes that work for color-blind viewers</li></ol><p>Remember, the goal of visualization is not just to make pretty pictures, but to communicate insights effectively!</p>',
                'category' => 'Data Science'
            ],
            [
                'title' => 'Neural Networks Explained: From Perceptrons to Deep Learning',
                'content' => '<p>Neural networks form the backbone of modern artificial intelligence systems. This post explains neural networks from the ground up, making complex concepts accessible to beginners.</p><h2>The Building Blocks: Neurons</h2><p>Artificial neural networks are inspired by the human brain. The basic unit, a neuron (or perceptron), takes multiple inputs, applies weights, and produces an output through an activation function.</p><h2>Network Architecture</h2><p>Neural networks typically consist of:</p><ul><li><strong>Input Layer:</strong> Receives the initial data</li><li><strong>Hidden Layers:</strong> Processes the inputs through weighted connections</li><li><strong>Output Layer:</strong> Produces the final prediction or classification</li></ul><h2>How Learning Happens</h2><p>Neural networks learn through a process called backpropagation, which involves:</p><ol><li>Forward pass: Data flows through the network to generate outputs</li><li>Error calculation: Comparing outputs with expected values</li><li>Backward pass: Adjusting weights to minimize errors</li><li>Iteration: Repeating the process to improve accuracy</li></ol><h2>Types of Neural Networks</h2><p>Different problems require different architectures:</p><ul><li><strong>Convolutional Neural Networks (CNNs):</strong> Excellent for image processing</li><li><strong>Recurrent Neural Networks (RNNs):</strong> Designed for sequential data like text or time series</li><li><strong>Generative Adversarial Networks (GANs):</strong> Create new content by learning patterns</li></ul><p>Understanding these fundamentals will help you navigate the exciting world of neural networks and deep learning!</p>',
                'category' => 'AI & ML'
            ]
        ];
        
        $stmt = $conn->prepare("INSERT INTO blog_posts (title, content, category) VALUES (?, ?, ?)");
        
        foreach ($blogPosts as $post) {
            $stmt->bind_param("sss", $post['title'], $post['content'], $post['category']);
            $stmt->execute();
        }
        
        $stmt->close();
    }
    
    // Check if projects table is empty
    $result = $conn->query("SELECT COUNT(*) as count FROM projects");
    $row = $result->fetch_assoc();
    
    if ($row['count'] == 0) {
        // Insert sample projects
        $projects = [
            [
                'title' => 'FoodLens AI',
                'description' => 'A complete web application built with flask that can recognize and classify foods, their Origins and The Restrictive Ingredients. The application can use both Image and Text from user and generate the result using multiple layers of AI models.',
                'category' => 'ai',
                'link' => 'https://github.com/SanjidHossain',
                'tags' => 'Python, Flask, AI, Computer Vision, NLP'
            ],
            [
                'title' => 'MultiLabel Article Classifier',
                'description' => 'A web application that can classify any form of News or article (complete or partial) from text (English) using ML model consisting of 18 categories.',
                'category' => 'ai',
                'link' => 'https://github.com/SanjidHossain',
                'tags' => 'Python, NLP, Machine Learning, Classification'
            ],
            [
                'title' => 'Data Analysis on Quality of Life',
                'description' => 'A complete data analysis project that uses population, GDP, Life expectancy and inflation rate data to determine the quality of life around the world & more detailed analys on multiple continents.',
                'category' => 'data',
                'link' => 'https://github.com/SanjidHossain',
                'tags' => 'Data Analysis, Python, Pandas, Visualization'
            ]
        ];
        
        $stmt = $conn->prepare("INSERT INTO projects (title, description, category, link, tags) VALUES (?, ?, ?, ?, ?)");
        
        foreach ($projects as $project) {
            $stmt->bind_param("sssss", $project['title'], $project['description'], $project['category'], $project['link'], $project['tags']);
            $stmt->execute();
        }
        
        $stmt->close();
    }
    
    // Check if research papers table is empty
    $result = $conn->query("SELECT COUNT(*) as count FROM research_papers");
    $row = $result->fetch_assoc();
    
    if ($row['count'] == 0) {
        // Insert sample research papers
        $papers = [
            [
                'title' => 'Refining Bengali Hate Speech Detection: Multi-Label Classification Using RNN and LSTM',
                'conference' => 'ICACTCE\'24 (Springer Lecture Notes in Networks and Systems LNNS)',
                'date' => null,
                'link' => '#',
                'abstract' => 'This research paper explores advanced methods for detecting hate speech in Bengali language using Recurrent Neural Networks (RNN) and Long Short-Term Memory (LSTM) models. The study implements a multi-label classification approach to categorize various forms of hate speech with improved accuracy.'
            ],
            [
                'title' => 'Road Condition Detection and Crowdsourced Data Collection for Accident Prevention: A Deep Learning Approach',
                'conference' => 'International Conference on Image Processing Theory, Tools and Applications (IPTA), France',
                'date' => '2023-10-15',
                'link' => '#',
                'abstract' => 'This paper presents a deep learning approach for detecting road conditions through image processing and leveraging crowdsourced data collection to prevent accidents. The system uses convolutional neural networks to classify road conditions from images captured by users.'
            ],
            [
                'title' => 'Hate Speech Detection Using Machine Learning In Bengali Languages',
                'conference' => 'International Conference on Intelligent Computing and Control Systems (ICICCS)',
                'date' => '2022-05-20',
                'link' => '#',
                'abstract' => 'This research focuses on developing machine learning models for detecting hate speech in Bengali language. Various classification algorithms are compared to determine the most effective approach for this challenging natural language processing task.'
            ]
        ];
        
        $stmt = $conn->prepare("INSERT INTO research_papers (title, conference, date, link, abstract) VALUES (?, ?, ?, ?, ?)");
        
        foreach ($papers as $paper) {
            $date = $paper['date'];
            $stmt->bind_param("sssss", $paper['title'], $paper['conference'], $date, $paper['link'], $paper['abstract']);
            $stmt->execute();
        }
        
        $stmt->close();
    }
    
    $conn->close();
    return true;
}

// Initialize database on first run
function initDatabase() {
    if (setupDatabase()) {
        insertSampleData();
        return true;
    }
    return false;
}

// Call initDatabase function to ensure the database is ready
initDatabase();
?>
