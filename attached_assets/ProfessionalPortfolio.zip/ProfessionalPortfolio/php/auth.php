<?php
/**
 * Authentication API
 * 
 * Handles user authentication for the admin panel
 */

// Include database configuration
require_once 'config.php';

// Set headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Start session
session_start();

// Determine action based on request method and parameters
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch ($action) {
    case 'login':
        loginUser();
        break;
    
    case 'logout':
        logoutUser();
        break;
    
    case 'check':
        checkLoginStatus();
        break;
    
    default:
        jsonResponse(false, 'Invalid action.');
}

// Login user
function loginUser() {
    // Check if user is already logged in
    if (isset($_SESSION['user_id'])) {
        jsonResponse(true, 'Already logged in.', ['loggedIn' => true]);
    }
    
    // Get credentials
    $username = isset($_POST['username']) ? sanitizeInput($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Validate input
    if (empty($username) || empty($password)) {
        jsonResponse(false, 'Username and password are required.');
    }
    
    // Connect to database
    $conn = dbConnect();
    
    if (!$conn) {
        jsonResponse(false, 'Database connection error. Please try again later.');
    }
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT id, username, password, email FROM admin_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Invalid username or password.');
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Invalid username or password.');
    }
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    
    // Update last login time (optional)
    $stmt = $conn->prepare("UPDATE admin_users SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Login successful.', ['loggedIn' => true]);
}

// Logout user
function logoutUser() {
    // Unset all session variables
    $_SESSION = [];
    
    // Destroy the session
    session_destroy();
    
    jsonResponse(true, 'Logout successful.', ['loggedIn' => false]);
}

// Check login status
function checkLoginStatus() {
    $loggedIn = isset($_SESSION['user_id']);
    
    jsonResponse(true, 'Login status retrieved.', [
        'loggedIn' => $loggedIn,
        'user' => $loggedIn ? [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'email' => $_SESSION['email']
        ] : null
    ]);
}
?>
