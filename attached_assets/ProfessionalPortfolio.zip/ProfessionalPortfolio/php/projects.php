<?php
/**
 * Projects Management API
 * 
 * Handles project CRUD operations
 */

// Include database configuration
require_once 'config.php';

// Set headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Connect to database
$conn = dbConnect();

if (!$conn) {
    jsonResponse(false, 'Database connection error. Please try again later.');
}

// Determine action based on request method and parameters
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch ($action) {
    case 'getAll':
        getAllProjects();
        break;
    
    case 'get':
        getProject();
        break;
    
    case 'create':
        createProject();
        break;
    
    case 'update':
        updateProject();
        break;
    
    case 'delete':
        deleteProject();
        break;
    
    case 'search':
        searchProjects();
        break;
    
    default:
        jsonResponse(false, 'Invalid action.');
}

// Get all projects
function getAllProjects() {
    global $conn;
    
    // Check if filter is applied
    $filter = isset($_GET['filter']) ? sanitizeInput($_GET['filter']) : '';
    
    $sql = "SELECT * FROM projects";
    
    if ($filter && $filter !== 'all') {
        $sql .= " WHERE category = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $filter);
    } else {
        $stmt = $conn->prepare($sql);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $projects = [];
    
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Projects retrieved successfully.', ['projects' => $projects]);
}

// Get a specific project
function getProject() {
    global $conn;
    
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid project ID.');
    }
    
    $stmt = $conn->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Project not found.');
    }
    
    $project = $result->fetch_assoc();
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Project retrieved successfully.', ['project' => $project]);
}

// Create a new project
function createProject() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $description = isset($_POST['description']) ? sanitizeInput($_POST['description']) : '';
    $category = isset($_POST['category']) ? sanitizeInput($_POST['category']) : '';
    $link = isset($_POST['link']) ? sanitizeInput($_POST['link']) : '';
    $tags = isset($_POST['tags']) ? sanitizeInput($_POST['tags']) : '';
    
    // Validate input
    if (empty($title) || empty($description) || empty($category)) {
        jsonResponse(false, 'Title, description, and category are required.');
    }
    
    // Insert new project
    $stmt = $conn->prepare("INSERT INTO projects (title, description, category, link, tags) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $description, $category, $link, $tags);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error creating project: ' . $stmt->error);
    }
    
    $newProjectId = $stmt->insert_id;
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Project created successfully.', ['id' => $newProjectId]);
}

// Update an existing project
function updateProject() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $description = isset($_POST['description']) ? sanitizeInput($_POST['description']) : '';
    $category = isset($_POST['category']) ? sanitizeInput($_POST['category']) : '';
    $link = isset($_POST['link']) ? sanitizeInput($_POST['link']) : '';
    $tags = isset($_POST['tags']) ? sanitizeInput($_POST['tags']) : '';
    
    // Validate input
    if ($id <= 0 || empty($title) || empty($description) || empty($category)) {
        jsonResponse(false, 'Invalid input. ID, title, description, and category are required.');
    }
    
    // Update project
    $stmt = $conn->prepare("UPDATE projects SET title = ?, description = ?, category = ?, link = ?, tags = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $title, $description, $category, $link, $tags, $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error updating project: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'No changes made or project not found.');
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Project updated successfully.');
}

// Delete a project
function deleteProject() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid project ID.');
    }
    
    $stmt = $conn->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error deleting project: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Project not found.');
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Project deleted successfully.');
}

// Search projects
function searchProjects() {
    global $conn;
    
    $term = isset($_GET['term']) ? sanitizeInput($_GET['term']) : '';
    
    if (empty($term)) {
        jsonResponse(false, 'Search term is required.');
    }
    
    $searchParam = "%{$term}%";
    
    $stmt = $conn->prepare("SELECT * FROM projects WHERE title LIKE ? OR description LIKE ? OR tags LIKE ?");
    $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $projects = [];
    
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Search results retrieved successfully.', ['projects' => $projects]);
}
?>
