<?php
/**
 * Blog Management API
 * 
 * Handles blog post CRUD operations
 */

// Include database configuration
require_once 'config.php';

// Set headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

// Connect to database
$conn = dbConnect();

if (!$conn) {
    jsonResponse(false, 'Database connection error. Please try again later.');
}

// Determine action based on request method and parameters
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch ($action) {
    case 'getAll':
        getAllPosts();
        break;
    
    case 'get':
        getPost();
        break;
    
    case 'create':
        createPost();
        break;
    
    case 'update':
        updatePost();
        break;
    
    case 'delete':
        deletePost();
        break;
    
    case 'search':
        searchPosts();
        break;
    
    default:
        jsonResponse(false, 'Invalid action.');
}

// Get all blog posts
function getAllPosts() {
    global $conn;
    
    // Check if category filter is applied
    $category = isset($_GET['category']) ? sanitizeInput($_GET['category']) : '';
    
    $sql = "SELECT * FROM blog_posts";
    
    if ($category && $category !== 'all') {
        $sql .= " WHERE category LIKE ?";
        $categoryParam = "%{$category}%";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $categoryParam);
    } else {
        $stmt = $conn->prepare($sql);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $posts = [];
    
    while ($row = $result->fetch_assoc()) {
        // Truncate content for list view
        $row['content'] = substr(strip_tags($row['content']), 0, 200) . (strlen($row['content']) > 200 ? '...' : '');
        $posts[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Blog posts retrieved successfully.', ['posts' => $posts]);
}

// Get a specific blog post
function getPost() {
    global $conn;
    
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid blog post ID.');
    }
    
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Blog post not found.');
    }
    
    $post = $result->fetch_assoc();
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Blog post retrieved successfully.', ['post' => $post]);
}

// Create a new blog post
function createPost() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $content = isset($_POST['content']) ? $_POST['content'] : ''; // Don't sanitize content to allow HTML
    $category = isset($_POST['category']) ? sanitizeInput($_POST['category']) : '';
    $videoUrl = isset($_POST['video_url']) ? sanitizeInput($_POST['video_url']) : '';
    $featured = isset($_POST['featured']) ? (bool)$_POST['featured'] : false;
    
    // Image upload handling
    $imageUrl = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $uploadDir = '../uploads/blog/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $filename = time() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $filename;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        
        // Check if image file is a valid image
        $validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($imageFileType, $validExtensions)) {
            jsonResponse(false, 'Only JPG, JPEG, PNG, GIF, and WEBP files are allowed.');
        }
        
        // Check file size (2MB max)
        if ($_FILES['image']['size'] > 2097152) {
            jsonResponse(false, 'File is too large. Maximum size is 2MB.');
        }
        
        // Upload file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imageUrl = 'uploads/blog/' . $filename; // Relative path for database
        } else {
            jsonResponse(false, 'Failed to upload image.');
        }
    }
    
    // Validate input
    if (empty($title) || empty($content)) {
        jsonResponse(false, 'Title and content are required.');
    }
    
    // Insert new post
    $stmt = $conn->prepare("INSERT INTO blog_posts (title, content, category, image_url, video_url, featured) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $title, $content, $category, $imageUrl, $videoUrl, $featured);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error creating blog post: ' . $stmt->error);
    }
    
    $newPostId = $stmt->insert_id;
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Blog post created successfully.', ['id' => $newPostId]);
}

// Update an existing blog post
function updatePost() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    // Get form data
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $title = isset($_POST['title']) ? sanitizeInput($_POST['title']) : '';
    $content = isset($_POST['content']) ? $_POST['content'] : ''; // Don't sanitize content to allow HTML
    $category = isset($_POST['category']) ? sanitizeInput($_POST['category']) : '';
    $videoUrl = isset($_POST['video_url']) ? sanitizeInput($_POST['video_url']) : '';
    $featured = isset($_POST['featured']) ? (bool)$_POST['featured'] : false;
    
    // Validate input
    if ($id <= 0 || empty($title) || empty($content)) {
        jsonResponse(false, 'Invalid input. ID, title, and content are required.');
    }
    
    // Check if we need to update the image
    $imageClause = '';
    $imageUrl = '';
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $uploadDir = '../uploads/blog/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $filename = time() . '_' . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $filename;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        
        // Check if image file is a valid image
        $validExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($imageFileType, $validExtensions)) {
            jsonResponse(false, 'Only JPG, JPEG, PNG, GIF, and WEBP files are allowed.');
        }
        
        // Check file size (2MB max)
        if ($_FILES['image']['size'] > 2097152) {
            jsonResponse(false, 'File is too large. Maximum size is 2MB.');
        }
        
        // Upload file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imageUrl = 'uploads/blog/' . $filename; // Relative path for database
            $imageClause = ', image_url = ?';
        } else {
            jsonResponse(false, 'Failed to upload image.');
        }
        
        // Get the old image to delete later if update is successful
        $stmt = $conn->prepare("SELECT image_url FROM blog_posts WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $oldImageUrl = '';
        
        if ($row = $result->fetch_assoc()) {
            $oldImageUrl = $row['image_url'];
        }
        
        $stmt->close();
    }
    
    // Prepare the SQL statement based on whether we're updating the image or not
    if (!empty($imageClause)) {
        $sql = "UPDATE blog_posts SET title = ?, content = ?, category = ?, video_url = ?, featured = ? $imageClause WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssis", $title, $content, $category, $videoUrl, $featured, $imageUrl, $id);
    } else {
        $sql = "UPDATE blog_posts SET title = ?, content = ?, category = ?, video_url = ?, featured = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssis", $title, $content, $category, $videoUrl, $featured, $id);
    }
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error updating blog post: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'No changes made or blog post not found.');
    }
    
    // Delete old image if we uploaded a new one
    if (!empty($oldImageUrl) && !empty($imageUrl)) {
        $oldFilePath = '../' . $oldImageUrl;
        if (file_exists($oldFilePath)) {
            unlink($oldFilePath);
        }
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Blog post updated successfully.');
}

// Delete a blog post
function deletePost() {
    global $conn;
    
    // Check if user is authenticated (simplified check)
    session_start();
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(false, 'Authentication required.');
    }
    
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'Invalid blog post ID.');
    }
    
    // Get the image URL before deleting the post to remove the file
    $stmt = $conn->prepare("SELECT image_url FROM blog_posts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $imageUrl = '';
    
    if ($row = $result->fetch_assoc()) {
        $imageUrl = $row['image_url'];
    }
    
    $stmt->close();
    
    // Delete the post from the database
    $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Error deleting blog post: ' . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Blog post not found.');
    }
    
    // Delete the associated image file if it exists
    if (!empty($imageUrl)) {
        $imagePath = '../' . $imageUrl;
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Blog post deleted successfully.');
}

// Search blog posts
function searchPosts() {
    global $conn;
    
    $term = isset($_GET['term']) ? sanitizeInput($_GET['term']) : '';
    
    if (empty($term)) {
        jsonResponse(false, 'Search term is required.');
    }
    
    $searchParam = "%{$term}%";
    
    $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE title LIKE ? OR content LIKE ? OR category LIKE ?");
    $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $posts = [];
    
    while ($row = $result->fetch_assoc()) {
        // Truncate content for list view
        $row['content'] = substr(strip_tags($row['content']), 0, 200) . (strlen($row['content']) > 200 ? '...' : '');
        $posts[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    jsonResponse(true, 'Search results retrieved successfully.', ['posts' => $posts]);
}
?>
