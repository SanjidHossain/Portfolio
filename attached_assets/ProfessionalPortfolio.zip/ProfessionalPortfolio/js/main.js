// Main JavaScript

document.addEventListener("DOMContentLoaded", function () {
    // Initialize AOS animation library
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    
    // Check for saved theme preference or use device preference
    const savedTheme = localStorage.getItem('theme') || 
                       (window.matchMedia("(prefers-color-scheme: dark)").matches ? 'dark' : 'light');
    
    // Apply the saved theme
    if (savedTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
        themeToggle.checked = true;
    }
    
    // Theme toggle click handler
    themeToggle.addEventListener('change', function() {
        if (this.checked) {
            document.body.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.removeAttribute('data-theme');
            localStorage.setItem('theme', 'light');
        }
    });

    // Navbar scroll effect
    const header = document.getElementById('header');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close mobile menu when clicking on a nav link
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Dynamically set active menu item based on scroll position
    const sections = document.querySelectorAll('section[id]');
    
    function highlightNavItem() {
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                document.querySelector('.nav-menu a[href*=' + sectionId + ']').classList.add('active');
            } else {
                document.querySelector('.nav-menu a[href*=' + sectionId + ']').classList.remove('active');
            }
        });
    }
    
    window.addEventListener('scroll', highlightNavItem);

    // Typing effect in hero section
    const occupations = [
        "Data Scientist",
        "AI/ML Engineer",
        "Data Analyst",
        "Software QA Engineer"
    ];
    
    let currentOccupationIndex = 0;
    let currentCharacterIndex = 0;
    let isDeleting = false;
    let typingInterval = 120;
    
    function type() {
        const currentOccupation = occupations[currentOccupationIndex];
        const occupationElement = document.getElementById('occupation');
        
        if (isDeleting) {
            // Deleting text
            occupationElement.textContent = currentOccupation.substring(0, currentCharacterIndex - 1);
            currentCharacterIndex--;
            typingInterval = 80;
        } else {
            // Typing text
            occupationElement.textContent = currentOccupation.substring(0, currentCharacterIndex + 1);
            currentCharacterIndex++;
            typingInterval = 120;
        }
        
        // If finished typing, start deleting after a pause
        if (!isDeleting && currentCharacterIndex === currentOccupation.length) {
            isDeleting = true;
            typingInterval = 1000; // Pause before deleting
        }
        
        // If finished deleting, move to next occupation
        if (isDeleting && currentCharacterIndex === 0) {
            isDeleting = false;
            currentOccupationIndex = (currentOccupationIndex + 1) % occupations.length;
        }
        
        setTimeout(type, typingInterval);
    }
    
    // Start the typing effect
    setTimeout(type, 1000);

    // Back to top button
    const backToTopBtn = document.querySelector('.back-to-top');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTopBtn.classList.add('show');
        } else {
            backToTopBtn.classList.remove('show');
        }
    });

    // Skill tabs functionality
    const tabBtns = document.querySelectorAll('.tab-btn');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons and content
            tabBtns.forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            btn.classList.add('active');
            document.getElementById(btn.getAttribute('data-tab')).classList.add('active');
        });
    });

    // Project filtering and search
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
    const searchInput = document.getElementById('project-search');
    
    // Filter projects by category
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons
            filterBtns.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            btn.classList.add('active');
            
            const filterValue = btn.getAttribute('data-filter');
            
            projectCards.forEach(card => {
                // Check if card matches filter and search terms
                const matchesFilter = filterValue === 'all' || card.getAttribute('data-category') === filterValue;
                const matchesSearch = searchInput.value === '' || 
                                      card.textContent.toLowerCase().includes(searchInput.value.toLowerCase());
                
                if (matchesFilter && matchesSearch) {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
    
    // Search functionality
    searchInput.addEventListener('input', () => {
        const activeFilter = document.querySelector('.filter-btn.active').getAttribute('data-filter');
        const searchTerm = searchInput.value.toLowerCase();
        
        projectCards.forEach(card => {
            // Check if card matches filter and search terms
            const matchesFilter = activeFilter === 'all' || card.getAttribute('data-category') === activeFilter;
            const matchesSearch = card.textContent.toLowerCase().includes(searchTerm);
            
            if (matchesFilter && matchesSearch) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    });

    // Project details modal
    const modal = document.getElementById('project-modal');
    const modalBody = document.querySelector('.modal-body');
    const closeModal = document.querySelector('.close-modal');
    const detailBtns = document.querySelectorAll('.project-details-btn');
    
    // Project details data
    const projectDetails = {
        'foodlens': {
            title: 'FoodLens AI',
            description: 'A complete web application built with Flask that can recognize and classify foods, their origins, and restrictive ingredients. The application can use both images and text from users and generate results using multiple layers of AI models.',
            features: [
                'Food recognition from images using computer vision',
                'Food classification with origin information',
                'Identification of restrictive ingredients for dietary considerations',
                'Text-based food querying',
                'Multi-modal AI processing pipeline'
            ],
            technologies: ['Python', 'Flask', 'TensorFlow', 'OpenCV', 'HTML/CSS', 'JavaScript', 'RESTful API'],
            link: 'https://github.com/SanjidHossain'
        },
        'article-classifier': {
            title: 'MultiLabel Article Classifier',
            description: 'A web application that can classify any form of news or article (complete or partial) from text (English) using an ML model consisting of 18 categories.',
            features: [
                'Multi-label classification of news articles',
                'Support for partial text analysis',
                'Classification across 18 distinct categories',
                'Web-based user interface for easy interaction',
                'High accuracy prediction model'
            ],
            technologies: ['Python', 'NLP', 'scikit-learn', 'Flask', 'HTML/CSS', 'JavaScript'],
            link: 'https://github.com/SanjidHossain'
        },
        'quality-of-life': {
            title: 'Data Analysis on Quality of Life',
            description: 'A complete data analysis project that uses population, GDP, life expectancy, and inflation rate data to determine the quality of life around the world & more detailed analysis on multiple continents.',
            features: [
                'Global quality of life assessment',
                'Continental and regional analysis',
                'Correlation between economic indicators and quality of life',
                'Interactive data visualizations',
                'Comprehensive statistical analysis'
            ],
            technologies: ['Python', 'Pandas', 'Matplotlib', 'Seaborn', 'Plotly', 'Jupyter Notebook'],
            link: 'https://github.com/SanjidHossain'
        },
        'hate-speech': {
            title: 'Refining Bengali Hate Speech Detection',
            description: 'A research project focused on multi-label classification of hate speech in Bengali language using RNN and LSTM models. This project was accepted for publication at ICACTCE\'24 (Springer Lecture Notes in Networks and Systems).',
            features: [
                'Multi-label hate speech classification',
                'Implementation of RNN and LSTM architectures',
                'Comprehensive dataset of Bengali text',
                'Performance comparison of different models',
                'Academic research with practical applications'
            ],
            technologies: ['Python', 'TensorFlow', 'RNN', 'LSTM', 'NLP', 'Bengali Language Processing'],
            link: 'https://github.com/SanjidHossain',
            paper: '#'
        },
        'road-condition': {
            title: 'Road Condition Detection',
            description: 'A deep learning approach for road condition detection and crowdsourced data collection for accident prevention. This research was presented at the International Conference on Image Processing Theory, Tools and Applications (IPTA) in France, 2023.',
            features: [
                'Real-time road condition detection',
                'Crowdsourced data collection system',
                'Accident prevention through early warning',
                'Deep learning classification models',
                'Mobile application interface'
            ],
            technologies: ['Python', 'TensorFlow', 'Computer Vision', 'Deep Learning', 'Mobile Development'],
            link: 'https://github.com/SanjidHossain',
            paper: '#'
        },
        'hate-speech-ml': {
            title: 'Hate Speech Detection in Bengali',
            description: 'A machine learning approach for detecting hate speech in Bengali language. This research was presented at the International Conference on Intelligent Computing and Control Systems (ICICCS) in 2022.',
            features: [
                'Bengali text classification',
                'Machine learning model training and evaluation',
                'NLP techniques for feature extraction',
                'Comparison of different ML algorithms',
                'High accuracy hate speech detection'
            ],
            technologies: ['Python', 'Machine Learning', 'NLP', 'Bengali Language Processing'],
            link: 'https://github.com/SanjidHossain',
            paper: '#'
        }
    };
    
    // Open modal with project details
    detailBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            
            const projectId = btn.getAttribute('data-id');
            const project = projectDetails[projectId];
            
            if (project) {
                let featuresHTML = '';
                project.features.forEach(feature => {
                    featuresHTML += `<li><i class="fas fa-check-circle"></i> ${feature}</li>`;
                });
                
                let technologiesHTML = '';
                project.technologies.forEach(tech => {
                    technologiesHTML += `<span class="tech-tag">${tech}</span>`;
                });
                
                let paperLinkHTML = '';
                if (project.paper) {
                    paperLinkHTML = `
                        <div class="modal-paper-link">
                            <a href="${project.paper}" class="btn btn-secondary" target="_blank">
                                <i class="fas fa-file-alt"></i> View Research Paper
                            </a>
                        </div>
                    `;
                }
                
                modalBody.innerHTML = `
                    <h2>${project.title}</h2>
                    <p class="modal-description">${project.description}</p>
                    <div class="modal-section">
                        <h3>Key Features</h3>
                        <ul class="feature-list">
                            ${featuresHTML}
                        </ul>
                    </div>
                    <div class="modal-section">
                        <h3>Technologies Used</h3>
                        <div class="tech-tags">
                            ${technologiesHTML}
                        </div>
                    </div>
                    <div class="modal-actions">
                        <a href="${project.link}" class="btn btn-primary" target="_blank">
                            <i class="fab fa-github"></i> View on GitHub
                        </a>
                        ${paperLinkHTML}
                    </div>
                `;
                
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
                
                // Add animation
                setTimeout(() => {
                    modal.querySelector('.modal-content').style.opacity = '1';
                    modal.querySelector('.modal-content').style.transform = 'translateY(0)';
                }, 50);
            }
        });
    });
    
    // Close modal
    closeModal.addEventListener('click', () => {
        modal.querySelector('.modal-content').style.opacity = '0';
        modal.querySelector('.modal-content').style.transform = 'translateY(-20px)';
        
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 300);
    });
    
    // Close modal when clicking outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.querySelector('.modal-content').style.opacity = '0';
            modal.querySelector('.modal-content').style.transform = 'translateY(-20px)';
            
            setTimeout(() => {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }, 300);
        }
    });

    // Contact form submission handler
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.getElementById('formStatus');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Serialize form data
            const formData = new FormData(contactForm);
            
            // Submit form using fetch API
            fetch(contactForm.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    formStatus.innerHTML = data.message;
                    formStatus.className = 'success';
                    contactForm.reset();
                } else {
                    formStatus.innerHTML = data.message;
                    formStatus.className = 'error';
                }
            })
            .catch(error => {
                formStatus.innerHTML = 'An error occurred. Please try again later.';
                formStatus.className = 'error';
                console.error('Error:', error);
            });
        });
    }

    // Load profile image
    const profileImage = document.getElementById('profile-image');
    if (profileImage) {
        // Create a placeholder until the real image loads
        profileImage.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f0f0'/%3E%3Ctext x='150' y='150' dominant-baseline='middle' text-anchor='middle' font-family='Arial' font-size='20' fill='%23888'%3ELoading...%3C/text%3E%3C/svg%3E";
        
        // Use a data URI (this would be replaced by a proper image URL in production)
        const img = new Image();
        img.onload = function() {
            profileImage.src = this.src;
        };
        
        // In production, you'd use a real image URL instead of a data URI
        img.src = "profile-image.jpg"; // This should be a proper URL in production
    }

    // Initialize paper links
    document.querySelectorAll('.paper-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Research paper will be available soon. This would link to the published paper in production.');
        });
    });
});
