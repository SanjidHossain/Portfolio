// Admin panel JavaScript

document.addEventListener("DOMContentLoaded", function () {
    // Check if user is logged in (via session)
    function checkLoginStatus() {
        fetch('../php/auth.php?action=check')
        .then(response => response.json())
        .then(data => {
            if (!data.loggedIn && !window.location.href.includes('login.html')) {
                window.location.href = 'login.html';
            }
        })
        .catch(error => {
            console.error('Error checking login status:', error);
        });
    }

    // Only run on admin pages
    if (window.location.href.includes('/admin/')) {
        checkLoginStatus();
    }

    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Validation
            if (!username || !password) {
                showMessage('Please enter both username and password', 'error');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('username', username);
            formData.append('password', password);
            
            // Submit login request
            fetch('../php/auth.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'dashboard.html';
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('An error occurred. Please try again.', 'error');
                console.error('Error:', error);
            });
        });
    }

    // Logout handler
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            fetch('../php/auth.php?action=logout')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'login.html';
                }
            })
            .catch(error => {
                console.error('Error logging out:', error);
            });
        });
    }

    // Show status messages
    function showMessage(message, type) {
        const statusElement = document.getElementById('statusMessage');
        if (statusElement) {
            statusElement.textContent = message;
            statusElement.className = type;
            statusElement.style.display = 'block';
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                statusElement.style.display = 'none';
            }, 5000);
        }
    }

    // Load blog posts for management
    function loadBlogPosts() {
        const blogTable = document.getElementById('blogTable');
        if (blogTable) {
            fetch('../php/blog.php?action=getAll')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const blogPosts = data.posts;
                    let tableContent = `
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    `;
                    
                    if (blogPosts.length === 0) {
                        tableContent += `
                            <tr>
                                <td colspan="4" class="no-data">No blog posts found</td>
                            </tr>
                        `;
                    } else {
                        blogPosts.forEach(post => {
                            tableContent += `
                                <tr>
                                    <td>${post.id}</td>
                                    <td>${post.title}</td>
                                    <td>${new Date(post.created_at).toLocaleDateString()}</td>
                                    <td>
                                        <button class="edit-btn" data-id="${post.id}">Edit</button>
                                        <button class="delete-btn" data-id="${post.id}">Delete</button>
                                    </td>
                                </tr>
                            `;
                        });
                    }
                    
                    blogTable.innerHTML = tableContent;
                    
                    // Add event listeners to edit and delete buttons
                    document.querySelectorAll('.edit-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const postId = this.getAttribute('data-id');
                            loadBlogPostForEdit(postId);
                        });
                    });
                    
                    document.querySelectorAll('.delete-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const postId = this.getAttribute('data-id');
                            if (confirm('Are you sure you want to delete this blog post?')) {
                                deleteBlogPost(postId);
                            }
                        });
                    });
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Error loading blog posts', 'error');
                console.error('Error:', error);
            });
        }
    }

    // Load blog post for editing
    function loadBlogPostForEdit(postId) {
        fetch(`../php/blog.php?action=get&id=${postId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const post = data.post;
                document.getElementById('postId').value = post.id;
                document.getElementById('postTitle').value = post.title;
                document.getElementById('postContent').value = post.content;
                document.getElementById('postCategory').value = post.category;
                
                // Show the form and scroll to it
                const blogForm = document.getElementById('blogForm');
                blogForm.scrollIntoView({ behavior: 'smooth' });
                
                // Change button text to indicate editing
                document.getElementById('blogSubmitBtn').textContent = 'Update Post';
            } else {
                showMessage(data.message, 'error');
            }
        })
        .catch(error => {
            showMessage('Error loading blog post for editing', 'error');
            console.error('Error:', error);
        });
    }

    // Delete blog post
    function deleteBlogPost(postId) {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', postId);
        
        fetch('../php/blog.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage('Blog post deleted successfully', 'success');
                loadBlogPosts(); // Reload the table
            } else {
                showMessage(data.message, 'error');
            }
        })
        .catch(error => {
            showMessage('Error deleting blog post', 'error');
            console.error('Error:', error);
        });
    }

    // Blog form submit handler
    const blogForm = document.getElementById('blogForm');
    if (blogForm) {
        blogForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const postId = document.getElementById('postId').value;
            const title = document.getElementById('postTitle').value;
            const content = document.getElementById('postContent').value;
            const category = document.getElementById('postCategory').value;
            
            // Validation
            if (!title || !content) {
                showMessage('Please enter both title and content', 'error');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('action', postId ? 'update' : 'create');
            if (postId) formData.append('id', postId);
            formData.append('title', title);
            formData.append('content', content);
            formData.append('category', category);
            
            // Submit blog post
            fetch('../php/blog.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(postId ? 'Blog post updated successfully' : 'Blog post created successfully', 'success');
                    blogForm.reset();
                    document.getElementById('postId').value = '';
                    document.getElementById('blogSubmitBtn').textContent = 'Create Post';
                    loadBlogPosts(); // Reload the table
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('An error occurred. Please try again.', 'error');
                console.error('Error:', error);
            });
        });
    }

    // Clear blog form
    const clearFormBtn = document.getElementById('clearFormBtn');
    if (clearFormBtn) {
        clearFormBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            blogForm.reset();
            document.getElementById('postId').value = '';
            document.getElementById('blogSubmitBtn').textContent = 'Create Post';
        });
    }

    // Load projects for management
    function loadProjects() {
        const projectTable = document.getElementById('projectTable');
        if (projectTable) {
            fetch('../php/projects.php?action=getAll')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const projects = data.projects;
                    let tableContent = `
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Actions</th>
                        </tr>
                    `;
                    
                    if (projects.length === 0) {
                        tableContent += `
                            <tr>
                                <td colspan="4" class="no-data">No projects found</td>
                            </tr>
                        `;
                    } else {
                        projects.forEach(project => {
                            tableContent += `
                                <tr>
                                    <td>${project.id}</td>
                                    <td>${project.title}</td>
                                    <td>${project.category}</td>
                                    <td>
                                        <button class="edit-project-btn" data-id="${project.id}">Edit</button>
                                        <button class="delete-project-btn" data-id="${project.id}">Delete</button>
                                    </td>
                                </tr>
                            `;
                        });
                    }
                    
                    projectTable.innerHTML = tableContent;
                    
                    // Add event listeners to edit and delete buttons
                    document.querySelectorAll('.edit-project-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const projectId = this.getAttribute('data-id');
                            loadProjectForEdit(projectId);
                        });
                    });
                    
                    document.querySelectorAll('.delete-project-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const projectId = this.getAttribute('data-id');
                            if (confirm('Are you sure you want to delete this project?')) {
                                deleteProject(projectId);
                            }
                        });
                    });
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Error loading projects', 'error');
                console.error('Error:', error);
            });
        }
    }

    // Load project for editing
    function loadProjectForEdit(projectId) {
        fetch(`../php/projects.php?action=get&id=${projectId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const project = data.project;
                document.getElementById('projectId').value = project.id;
                document.getElementById('projectTitle').value = project.title;
                document.getElementById('projectDescription').value = project.description;
                document.getElementById('projectCategory').value = project.category;
                document.getElementById('projectLink').value = project.link;
                document.getElementById('projectTags').value = project.tags;
                
                // Show the form and scroll to it
                const projectForm = document.getElementById('projectForm');
                projectForm.scrollIntoView({ behavior: 'smooth' });
                
                // Change button text to indicate editing
                document.getElementById('projectSubmitBtn').textContent = 'Update Project';
            } else {
                showMessage(data.message, 'error');
            }
        })
        .catch(error => {
            showMessage('Error loading project for editing', 'error');
            console.error('Error:', error);
        });
    }

    // Delete project
    function deleteProject(projectId) {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', projectId);
        
        fetch('../php/projects.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage('Project deleted successfully', 'success');
                loadProjects(); // Reload the table
            } else {
                showMessage(data.message, 'error');
            }
        })
        .catch(error => {
            showMessage('Error deleting project', 'error');
            console.error('Error:', error);
        });
    }

    // Project form submit handler
    const projectForm = document.getElementById('projectForm');
    if (projectForm) {
        projectForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const projectId = document.getElementById('projectId').value;
            const title = document.getElementById('projectTitle').value;
            const description = document.getElementById('projectDescription').value;
            const category = document.getElementById('projectCategory').value;
            const link = document.getElementById('projectLink').value;
            const tags = document.getElementById('projectTags').value;
            
            // Validation
            if (!title || !description || !category) {
                showMessage('Please fill all required fields', 'error');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('action', projectId ? 'update' : 'create');
            if (projectId) formData.append('id', projectId);
            formData.append('title', title);
            formData.append('description', description);
            formData.append('category', category);
            formData.append('link', link);
            formData.append('tags', tags);
            
            // Submit project
            fetch('../php/projects.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(projectId ? 'Project updated successfully' : 'Project created successfully', 'success');
                    projectForm.reset();
                    document.getElementById('projectId').value = '';
                    document.getElementById('projectSubmitBtn').textContent = 'Create Project';
                    loadProjects(); // Reload the table
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('An error occurred. Please try again.', 'error');
                console.error('Error:', error);
            });
        });
    }

    // Clear project form
    const clearProjectFormBtn = document.getElementById('clearProjectFormBtn');
    if (clearProjectFormBtn) {
        clearProjectFormBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            projectForm.reset();
            document.getElementById('projectId').value = '';
            document.getElementById('projectSubmitBtn').textContent = 'Create Project';
        });
    }

    // Load research papers for management
    function loadResearchPapers() {
        const researchTable = document.getElementById('researchTable');
        if (researchTable) {
            fetch('../php/research.php?action=getAll')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const papers = data.papers;
                    let tableContent = `
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Conference</th>
                            <th>Actions</th>
                        </tr>
                    `;
                    
                    if (papers.length === 0) {
                        tableContent += `
                            <tr>
                                <td colspan="4" class="no-data">No research papers found</td>
                            </tr>
                        `;
                    } else {
                        papers.forEach(paper => {
                            tableContent += `
                                <tr>
                                    <td>${paper.id}</td>
                                    <td>${paper.title}</td>
                                    <td>${paper.conference}</td>
                                    <td>
                                        <button class="edit-research-btn" data-id="${paper.id}">Edit</button>
                                        <button class="delete-research-btn" data-id="${paper.id}">Delete</button>
                                    </td>
                                </tr>
                            `;
                        });
                    }
                    
                    researchTable.innerHTML = tableContent;
                    
                    // Add event listeners to edit and delete buttons
                    document.querySelectorAll('.edit-research-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const paperId = this.getAttribute('data-id');
                            loadResearchPaperForEdit(paperId);
                        });
                    });
                    
                    document.querySelectorAll('.delete-research-btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const paperId = this.getAttribute('data-id');
                            if (confirm('Are you sure you want to delete this research paper?')) {
                                deleteResearchPaper(paperId);
                            }
                        });
                    });
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                showMessage('Error loading research papers', 'error');
                console.error('Error:', error);
            });
        }
    }

    // Load data tables on dashboard
    if (window.location.href.includes('dashboard.html')) {
        loadBlogPosts();
        loadProjects();
        loadResearchPapers();
    }

    // Tab navigation in dashboard
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabButtons.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons and contents
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to clicked button and corresponding content
                this.classList.add('active');
                document.getElementById(this.getAttribute('data-tab')).classList.add('active');
            });
        });
    }
});
