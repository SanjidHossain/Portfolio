/*
* Md. Sanjid Hossain - Portfolio
* Author: Md. Sanjid Hossain
* Version: 1.0
* Description: Theme toggle functionality
*/

document.addEventListener('DOMContentLoaded', function() {
    'use strict';
    
    // Theme toggle
    const themeCheckbox = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;
    
    // Check for saved theme preference or use default
    const currentTheme = localStorage.getItem('theme') || 'dark';
    
    // Apply the saved theme on page load
    if (currentTheme === 'light') {
        htmlElement.classList.remove('dark-theme');
        document.body.classList.remove('dark-theme');
        // Update checkbox state to match theme
        if (themeCheckbox) themeCheckbox.checked = false;
    } else {
        htmlElement.classList.add('dark-theme');
        document.body.classList.add('dark-theme');
        // Update checkbox state to match theme
        if (themeCheckbox) themeCheckbox.checked = true;
    }
    
    // Toggle theme when checkbox changes
    if (themeCheckbox) {
        themeCheckbox.addEventListener('change', function() {
            if (this.checked) {
                // Switch to dark theme
                htmlElement.classList.add('dark-theme');
                document.body.classList.add('dark-theme');
                localStorage.setItem('theme', 'dark');
            } else {
                // Switch to light theme
                htmlElement.classList.remove('dark-theme');
                document.body.classList.remove('dark-theme');
                localStorage.setItem('theme', 'light');
            }
        });
    }
});
