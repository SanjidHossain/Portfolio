/*
* Md. Sanjid Hossain - Portfolio
* Author: Md. Sanjid Hossain
* Version: 1.0
* Description: Filter and search functionality for projects
*/

document.addEventListener('DOMContentLoaded', function() {
    'use strict';
    
    // Project filtering
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectItems = document.querySelectorAll('.project-item');
    const projectSearch = document.getElementById('projectSearch');
    
    // Filter projects by category
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                const filterValue = this.getAttribute('data-filter');
                
                // Show or hide projects based on filter
                projectItems.forEach(item => {
                    if (filterValue === 'all') {
                        item.style.display = 'block';
                    } else {
                        if (item.getAttribute('data-category').includes(filterValue)) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    }
                });
                
                // Clear search input when filtering
                if (projectSearch) {
                    projectSearch.value = '';
                }
                
                // Trigger AOS refresh
                AOS.refresh();
            });
        });
    }
    
    // Search projects by title and description
    if (projectSearch) {
        projectSearch.addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            
            projectItems.forEach(item => {
                const title = item.querySelector('h3').textContent.toLowerCase();
                const description = item.querySelector('p').textContent.toLowerCase();
                
                if (title.includes(searchValue) || description.includes(searchValue)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
            
            // Reset active filter button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            document.querySelector('[data-filter="all"]').classList.add('active');
            
            // Trigger AOS refresh
            AOS.refresh();
        });
    }
    
    // Blog pagination
    const paginationButtons = document.querySelectorAll('.pagination-btn');
    
    if (paginationButtons.length > 0) {
        paginationButtons.forEach(button => {
            button.addEventListener('click', function() {
                // For demonstration purposes only
                // In a real implementation, this would load different blog posts
                
                // Remove active class from all buttons
                paginationButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                if (!this.classList.contains('next')) {
                    this.classList.add('active');
                }
                
                // Scroll to blog section
                document.querySelector('#blog').scrollIntoView({ behavior: 'smooth' });
            });
        });
    }
});
