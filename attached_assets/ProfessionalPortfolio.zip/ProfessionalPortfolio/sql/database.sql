-- Database structure for Sanjid Hossain's Portfolio

-- Create database
CREATE DATABASE IF NOT EXISTS sanjid_portfolio;
USE sanjid_portfolio;

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT(11) NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY (username),
    UNIQUE KEY (email)
);

-- Insert default admin user (password: admin123)
INSERT INTO admin_users (username, password, email) 
VALUES ('sanjid', '$2y$10$3e6QuFh9KH/pxK7QXdIUlOX95Yp8eiOLIjDp9jYqwU6FQ1G5q.kGa', 'sanjidds99@gmail.com')
ON DUPLICATE KEY UPDATE email = VALUES(email);

-- Blog posts table
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT(11) NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(100) DEFAULT NULL,
    image_url VARCHAR(255) DEFAULT NULL,
    video_url VARCHAR(255) DEFAULT NULL,
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

-- Sample blog posts
INSERT INTO blog_posts (title, content, category) VALUES
('Getting Started with Machine Learning', '<p>Machine learning is a powerful tool that allows computers to learn from data and make predictions or decisions without being explicitly programmed. This blog post will guide you through the basics of machine learning and how to get started with your first projects.</p><h2>What is Machine Learning?</h2><p>Machine learning is a subset of artificial intelligence that focuses on building systems that can learn from and make decisions based on data. These systems improve their performance over time as they are exposed to more data.</p><h2>Key Machine Learning Concepts</h2><ul><li><strong>Supervised Learning:</strong> The algorithm learns from labeled training data, helping it to predict outcomes for unforeseen data.</li><li><strong>Unsupervised Learning:</strong> The algorithm learns patterns from unlabeled data.</li><li><strong>Reinforcement Learning:</strong> The algorithm learns to perform an action based on reward feedback.</li></ul><h2>Getting Started</h2><p>To get started with machine learning, you need to have a good understanding of programming (preferably Python), statistics, and linear algebra. Here are some steps to begin your journey:</p><ol><li>Learn Python programming</li><li>Study statistics and probability</li><li>Understand linear algebra concepts</li><li>Start with simple datasets like Iris or MNIST</li><li>Implement basic algorithms such as linear regression or k-means clustering</li></ol><p>With these foundations, you\'ll be well on your way to becoming proficient in machine learning!</p>', 'AI & ML'),
('Data Visualization Techniques for Effective Communication', '<p>Data visualization is a critical skill for data scientists and analysts. Effective visualizations can communicate complex findings clearly and persuasively. This post explores key techniques for creating impactful data visualizations.</p><h2>Why Visualization Matters</h2><p>Humans are visual creatures. We process visual information faster and more effectively than text. Good visualizations can reveal patterns, trends, and outliers that might be missed in raw data.</p><h2>Essential Visualization Types</h2><ul><li><strong>Bar Charts:</strong> Best for comparing values across categories</li><li><strong>Line Charts:</strong> Ideal for showing trends over time</li><li><strong>Scatter Plots:</strong> Perfect for showing relationships between two variables</li><li><strong>Heatmaps:</strong> Great for displaying patterns in dense data</li><li><strong>Pie Charts:</strong> Useful for showing proportions of a whole (use sparingly)</li></ul><h2>Design Principles</h2><p>Follow these principles to create effective visualizations:</p><ol><li><strong>Simplicity:</strong> Remove clutter and unnecessary elements</li><li><strong>Clarity:</strong> Ensure your message is clear and straightforward</li><li><strong>Accuracy:</strong> Represent data truthfully without distortion</li><li><strong>Context:</strong> Provide adequate context for interpretation</li><li><strong>Accessibility:</strong> Use color schemes that work for color-blind viewers</li></ol><p>Remember, the goal of visualization is not just to make pretty pictures, but to communicate insights effectively!</p>', 'Data Science'),
('Neural Networks Explained: From Perceptrons to Deep Learning', '<p>Neural networks form the backbone of modern artificial intelligence systems. This post explains neural networks from the ground up, making complex concepts accessible to beginners.</p><h2>The Building Blocks: Neurons</h2><p>Artificial neural networks are inspired by the human brain. The basic unit, a neuron (or perceptron), takes multiple inputs, applies weights, and produces an output through an activation function.</p><h2>Network Architecture</h2><p>Neural networks typically consist of:</p><ul><li><strong>Input Layer:</strong> Receives the initial data</li><li><strong>Hidden Layers:</strong> Processes the inputs through weighted connections</li><li><strong>Output Layer:</strong> Produces the final prediction or classification</li></ul><h2>How Learning Happens</h2><p>Neural networks learn through a process called backpropagation, which involves:</p><ol><li>Forward pass: Data flows through the network to generate outputs</li><li>Error calculation: Comparing outputs with expected values</li><li>Backward pass: Adjusting weights to minimize errors</li><li>Iteration: Repeating the process to improve accuracy</li></ol><h2>Types of Neural Networks</h2><p>Different problems require different architectures:</p><ul><li><strong>Convolutional Neural Networks (CNNs):</strong> Excellent for image processing</li><li><strong>Recurrent Neural Networks (RNNs):</strong> Designed for sequential data like text or time series</li><li><strong>Generative Adversarial Networks (GANs):</strong> Create new content by learning patterns</li></ul><p>Understanding these fundamentals will help you navigate the exciting world of neural networks and deep learning!</p>', 'AI & ML');

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id INT(11) NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    link VARCHAR(255) DEFAULT NULL,
    tags VARCHAR(255) DEFAULT NULL,
    image_url VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

-- Sample projects
INSERT INTO projects (title, description, category, link, tags) VALUES
('Smart Waiter Call System', 'An innovative system designed to modernize restaurant service by providing a digital solution for customers to call waiters. Enhances customer experience and improves restaurant efficiency.', 'ai', 'https://github.com/SanjidHossain/Smart-Waiter-Call-System', 'IoT, Hardware, Customer Service, Restaurant Tech'),
('MEME Finder AI', 'An AI-powered tool that searches and retrieves memes based on text descriptions. Uses natural language processing to understand meme content and context for accurate retrieval.', 'ai', 'https://github.com/SanjidHossain/MEME-Finder-AI', 'AI, NLP, Image Recognition, Python, Deep Learning'),
('Traffic Management System (YOLO approach)', 'An advanced traffic management solution that uses YOLO (You Only Look Once) object detection to monitor and analyze traffic patterns in real-time. Helps optimize traffic flow and enhance road safety.', 'ai', 'https://github.com/SanjidHossain/Traffic-Managment-System-YOLO-approach', 'Computer Vision, YOLO, Object Detection, Traffic Analysis'),
('AI Schema Extractor', 'A tool that automatically extracts database schemas from existing applications using AI. Simplifies database migration and documentation processes for developers.', 'ai', 'https://github.com/SanjidHossain/AI-schema-extractor', 'AI, Database, Schema Extraction, Development Tools'),
('FoodLens AI', 'A complete web application built with flask that can recognize and classify foods, their Origins and The Restrictive Ingredients. The application can use both Image and Text from user and generate the result using multiple layers of AI models.', 'ai', 'https://github.com/SanjidHossain', 'Python, Flask, AI, Computer Vision, NLP'),
('MultiLabel Article Classifier', 'A web application that can classify any form of News or article (complete or partial) from text (English) using ML model consisting of 18 categories.', 'ai', 'https://github.com/SanjidHossain', 'Python, NLP, Machine Learning, Classification'),
('Data Analysis on Quality of Life', 'A complete data analysis project that uses population, GDP, Life expectancy and inflation rate data to determine the quality of life around the world & more detailed analys on multiple continents.', 'data', 'https://github.com/SanjidHossain', 'Data Analysis, Python, Pandas, Visualization');

-- Research papers table
CREATE TABLE IF NOT EXISTS research_papers (
    id INT(11) NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    conference VARCHAR(255) NOT NULL,
    date DATE DEFAULT NULL,
    link VARCHAR(255) DEFAULT NULL,
    abstract TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

-- Sample research papers
INSERT INTO research_papers (title, conference, date, link, abstract) VALUES
('Refining Bengali Hate Speech Detection: Multi-Label Classification Using RNN and LSTM', 'ICACTCE\'24 (Springer Lecture Notes in Networks and Systems LNNS)', NULL, '#', 'This research paper explores advanced methods for detecting hate speech in Bengali language using Recurrent Neural Networks (RNN) and Long Short-Term Memory (LSTM) models. The study implements a multi-label classification approach to categorize various forms of hate speech with improved accuracy.'),
('Road Condition Detection and Crowdsourced Data Collection for Accident Prevention: A Deep Learning Approach', 'International Conference on Image Processing Theory, Tools and Applications (IPTA), France', '2023-10-15', '#', 'This paper presents a deep learning approach for detecting road conditions through image processing and leveraging crowdsourced data collection to prevent accidents. The system uses convolutional neural networks to classify road conditions from images captured by users.'),
('Hate Speech Detection Using Machine Learning In Bengali Languages', 'International Conference on Intelligent Computing and Control Systems (ICICCS)', '2022-05-20', '#', 'This research focuses on developing machine learning models for detecting hate speech in Bengali language. Various classification algorithms are compared to determine the most effective approach for this challenging natural language processing task.');

-- Contact messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
